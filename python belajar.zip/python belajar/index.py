print("hello word")
print("hallo kakak apa kabar")

# bermain variable disini
nama = "nerva"
umur = 13

# untuk mencetak teks ke layar
print("nama pacar saya adalah",nama, "umur pacar saya", umur ,"tahun")

# bermain dengan media if dan else
if umur >= 19 :
    print("yah umur kamu sudah tua buatku maafya")
else:
    print("yay semoga kita cocok ya bahwa kita itu seumuran")

# ini adalah kode untuk bagian perulangan berkali kali
for i in range(4):
    print("selamat ulang tahun mama 😊", i)

# bagian ini adalah untuk user bisa ngisi di sini
nama = input("Siapakah nama kakak ini ? ")
umur = int(input("berapakah umur kakak ini ?"))

if umur >= 18:
    print("halo kakak",nama ,"wah umurnya kakak ini sudah dewasa ya")
else:
    print("halo kakak", nama +",wah umur kakak belum mencukupi untuk masuk disini maaf ya")